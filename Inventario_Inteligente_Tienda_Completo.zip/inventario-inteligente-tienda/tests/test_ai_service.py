import json
from uuid import uuid4

import pytest

from backend.services.ai_service import _extract_json


def test_extract_valid_json():
    payload = '{"recomendaciones": []}'
    assert _extract_json(payload) == {"recomendaciones": []}


def test_extract_json_from_markdown():
    payload = '```json\n{"recomendaciones": []}\n```'
    assert _extract_json(payload) == {"recomendaciones": []}


def test_extract_invalid_json():
    with pytest.raises(ValueError):
        _extract_json("sin json")
