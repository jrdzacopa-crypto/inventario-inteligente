# Guía por etapas

## Etapa 1 — Arquitectura
- Archivo: `README.md`
- Función: documenta el flujo Navegador → FastAPI → Supabase y FastAPI → Ollama.
- Comprobación: revisar que la aplicación tenga una sola fuente persistente y que el frontend no contenga claves de Supabase.

## Etapa 2 — Supabase
- `sql/001_schema.sql`: crea tablas, relaciones, índices, RLS, políticas y `registrar_venta`.
- `sql/002_seed.sql`: agrega categorías, productos y ventas simuladas.
- Ejecución: Supabase → SQL Editor → ejecutar primero `001_schema.sql`, después `002_seed.sql`.
- Comprobación: en Table Editor revisar `categorias`, `productos`, `ventas`, `recomendaciones_ia`.

## Etapa 3 — Backend
- `backend/main.py`: endpoints REST, manejo de errores y servidor web.
- `backend/config.py`: variables de entorno.
- `backend/supabase_client.py`: cliente Supabase.
- `backend/schemas.py`: validación Pydantic.
- `backend/services/inventory_service.py`: consultas, CRUD, métricas y ventas.
- `backend/services/ai_service.py`: comunicación con Ollama y validación JSON.
- Ejecución: `uvicorn backend.main:app --reload`.
- Comprobación: abrir `http://127.0.0.1:8000/docs`.

## Etapa 4 — Frontend
- `frontend/index.html`: estructura de las pantallas.
- `frontend/styles.css`: estilos.
- `frontend/app.js`: navegación y consumo de API.
- FastAPI sirve los archivos mediante `StaticFiles`.
- Comprobación: abrir `http://127.0.0.1:8000`.

## Etapa 5 — IA local
- `backend/services/ai_service.py`.
- Modelo por defecto: `llama3.2:3b`.
- Instalar y descargar: `ollama pull llama3.2:3b`.
- Comprobación: `ollama list`.
- Después ejecutar FastAPI y abrir `Análisis IA`.

## Etapa 6 — Prueba de extremo a extremo
1. Dashboard carga productos.
2. Crear o editar un producto.
3. Registrar una venta.
4. Confirmar disminución de stock.
5. Ejecutar Análisis IA.
6. Confirmar prioridad y motivo.
7. Recargar el navegador.
8. Confirmar que la recomendación permanece en Supabase.

## Etapa 7 — Pruebas técnicas
```bash
python -m py_compile backend/main.py backend/config.py backend/schemas.py backend/supabase_client.py backend/services/ai_service.py backend/services/inventory_service.py
pytest -q tests
```

Resultado esperado del paquete inicial:
`3 passed`.

## Escenarios para la presentación
- Alta: Playera negra, stock bajo y ventas recientes aceleradas.
- Media: Detergente, stock cercano al mínimo y demanda moderada.
- Baja: Cuaderno profesional, stock amplio y baja frecuencia de venta.

Las etiquetas finales las determina el modelo local a partir de los datos enviados; los escenarios de prueba están diseñados para ofrecer señales diferenciadas.
