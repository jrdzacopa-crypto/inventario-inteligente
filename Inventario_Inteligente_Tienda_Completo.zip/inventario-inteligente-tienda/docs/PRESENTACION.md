# Guion breve para la presentación

## Problema
Una pequeña tienda puede tener productos con poca existencia sin identificar cuáles deben reponerse primero.

## Solución
El sistema centraliza productos, inventario y ventas en Supabase y utiliza un modelo local para analizar múltiples señales de demanda.

## Demostración
1. Mostrar Dashboard.
2. Entrar a Productos y mostrar los productos simulados.
3. Entrar a Ventas y registrar una venta.
4. Volver a Inventario y mostrar el stock actualizado.
5. Entrar a Análisis IA.
6. Ejecutar análisis.
7. Mostrar prioridad, motivo y confianza.
8. Recargar la página y demostrar que la información permanece guardada.

## Qué hace que sea IA
El backend no envía solamente `stock < mínimo`. Construye variables de comportamiento:
- ventas 7 días;
- ventas 30 días;
- velocidad diaria de venta;
- comparación de velocidad reciente contra la mensual;
- días estimados de cobertura;
- stock mínimo;
- categoría;
- precio.

El modelo local interpreta estas señales y devuelve una clasificación estructurada.

## Qué pasa si falla Ollama
La aplicación no inventa una respuesta. Muestra un error entendible y conserva los datos de Supabase.

## Qué pasa si se vende más que el stock
La función transaccional de PostgreSQL rechaza la venta y el backend la convierte en un mensaje para el usuario.
