const state = { products: [], categories: [] };

const $ = (id) => document.getElementById(id);

function showAlert(message, error = false) {
  const el = $("alert");
  el.textContent = message;
  el.className = `alert ${error ? "error" : ""}`;
  setTimeout(() => el.classList.add("hidden"), 4500);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  let data = null;
  try { data = await response.json(); } catch (_) {}
  if (!response.ok) {
    throw new Error(data?.detail || "No fue posible completar la operación.");
  }
  return data;
}

function money(value) {
  return new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(value);
}

function dateText(value) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString("es-MX");
}

function stockBadge(stock, min) {
  if (stock <= min) return '<span class="badge badge-high">Reposición recomendada</span>';
  if (stock <= min * 1.5) return '<span class="badge badge-low">Stock bajo</span>';
  return '<span class="badge badge-ok">Stock suficiente</span>';
}

function priorityBadge(priority) {
  const cls = priority === "ALTA" ? "badge-high" : priority === "MEDIA" ? "badge-medium" : "badge-ok";
  return `<span class="badge ${cls}">${priority}</span>`;
}

document.querySelectorAll(".nav").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav").forEach(x => x.classList.remove("active"));
    document.querySelectorAll(".section").forEach(x => x.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.section).classList.add("active");
    if (btn.dataset.section === "dashboard") loadDashboard();
    if (btn.dataset.section === "productos") loadProducts();
    if (btn.dataset.section === "inventario") loadInventory();
    if (btn.dataset.section === "ventas") loadSales();
    if (btn.dataset.section === "ia") loadRecommendations();
  });
});

async function loadHealth() {
  try {
    const h = await api("/api/health");
    $("connection").textContent = `Supabase ${h.supabase} · Ollama ${h.ollama}`;
    $("connection").style.background = h.supabase === "OK" ? "#e6f7f0" : "#ffe5e5";
    $("connection").style.color = h.supabase === "OK" ? "#12805c" : "#c62828";
  } catch (e) {
    $("connection").textContent = "Backend no disponible";
    $("connection").style.background = "#ffe5e5";
    $("connection").style.color = "#c62828";
  }
}

async function loadCategories() {
  state.categories = await api("/api/categorias");
  const options = state.categories.map(c => `<option value="${c.id}">${escapeHtml(c.nombre)}</option>`).join("");
  $("categoryFilter").innerHTML = '<option value="">Todas las categorías</option>' + options;
  $("productCategory").innerHTML = '<option value="">Selecciona...</option>' + options;
}

async function loadProducts() {
  try {
    const search = encodeURIComponent($("productSearch").value || "");
    const cat = $("categoryFilter").value;
    const query = new URLSearchParams();
    if (search) query.set("search", decodeURIComponent(search));
    if (cat) query.set("categoria_id", cat);
    state.products = await api(`/api/productos?${query.toString()}`);

    $("productsTable").innerHTML = state.products.map(p => `
      <tr>
        <td><strong>${escapeHtml(p.nombre)}</strong></td>
        <td>${escapeHtml(p.categoria)}</td>
        <td>${money(p.precio)}</td>
        <td>${p.stock_actual}</td>
        <td>${p.stock_minimo}</td>
        <td>${stockBadge(p.stock_actual, p.stock_minimo)}</td>
        <td>
          <button class="action" onclick='editProduct(${JSON.stringify(p)})'>Editar</button>
          <button class="action danger" onclick="deactivateProduct('${p.id}')">Desactivar</button>
        </td>
      </tr>`).join("") || '<tr><td colspan="7">No hay productos.</td></tr>';

    fillSaleProducts();
  } catch (e) { showAlert(e.message, true); }
}

async function loadInventory() {
  try {
    const rows = await api("/api/inventario");
    $("inventoryTable").innerHTML = rows.map(p => `
      <tr>
        <td><strong>${escapeHtml(p.producto)}</strong><br><small>${escapeHtml(p.categoria)}</small></td>
        <td>${p.stock_actual}</td>
        <td>${p.stock_minimo}</td>
        <td>${p.ventas_7_dias}</td>
        <td>${p.ventas_30_dias}</td>
        <td>${p.velocidad_diaria_7d.toFixed(2)}</td>
        <td>${p.dias_cobertura == null ? "Sin ventas" : p.dias_cobertura + " días"}</td>
        <td>${stockBadge(p.stock_actual, p.stock_minimo)}</td>
      </tr>`).join("");
  } catch (e) { showAlert(e.message, true); }
}

async function loadSales() {
  try {
    const rows = await api("/api/ventas?limit=50");
    $("salesTable").innerHTML = rows.map(s => `
      <tr><td>${escapeHtml(s.productos?.nombre || "Producto")}</td><td>${s.cantidad}</td><td>${money(s.precio_unitario)}</td><td>${dateText(s.fecha_venta)}</td></tr>
    `).join("") || '<tr><td colspan="4">No hay ventas.</td></tr>';
  } catch (e) { showAlert(e.message, true); }
}

function fillSaleProducts() {
  $("saleProduct").innerHTML = state.products
    .filter(p => p.activo && p.stock_actual > 0)
    .map(p => `<option value="${p.id}">${escapeHtml(p.nombre)} · stock ${p.stock_actual}</option>`)
    .join("");
}

async function submitSale(event) {
  event.preventDefault();
  try {
    await api("/api/ventas", {
      method: "POST",
      body: JSON.stringify({
        producto_id: $("saleProduct").value,
        cantidad: Number($("saleQuantity").value),
        fecha_venta: $("saleDate").value || null,
      }),
    });
    showAlert("Venta registrada y stock actualizado.");
    $("saleQuantity").value = "";
    await loadProducts();
    await loadSales();
    await loadInventory();
    await loadDashboard();
  } catch (e) { showAlert(e.message, true); }
}

async function loadDashboard() {
  try {
    const d = await api("/api/dashboard");
    $("totalProducts").textContent = d.total_productos;
    $("lowStock").textContent = d.productos_stock_bajo;
    $("recentSales").textContent = d.ventas_recientes.length;
    $("highPriority").textContent = d.productos_prioridad_alta;
    $("dashboardInventory").innerHTML = d.resumen_inventario.map(p => `
      <tr><td>${escapeHtml(p.producto)}</td><td>${escapeHtml(p.categoria)}</td><td>${p.stock_actual}</td><td>${p.stock_minimo}</td><td>${p.ventas_7_dias}</td><td>${stockBadge(p.stock_actual,p.stock_minimo)}</td></tr>
    `).join("");
  } catch (e) { showAlert(e.message, true); }
}

async function loadRecommendations() {
  try {
    const rows = await api("/api/recomendaciones");
    $("aiTable").innerHTML = rows.map(r => `
      <tr>
        <td><strong>${escapeHtml(r.productos?.nombre || "Producto")}</strong></td>
        <td>${r.productos?.stock_actual ?? "—"}</td>
        <td>—</td><td>—</td>
        <td>${priorityBadge(r.prioridad)}</td>
        <td>${Math.round(Number(r.nivel_confianza) * 100)}%</td>
        <td>${escapeHtml(r.motivo)}</td>
      </tr>
    `).join("") || '<tr><td colspan="7">Todavía no hay análisis guardados. Ejecuta el análisis IA.</td></tr>';
  } catch (e) { showAlert(e.message, true); }
}

async function runAI() {
  const btn = $("runAI");
  btn.disabled = true;
  btn.textContent = "Analizando...";
  try {
    const result = await api("/api/analisis-ia", { method: "POST" });
    $("aiTable").innerHTML = result.recomendaciones.map(r => `
      <tr>
        <td><strong>${escapeHtml(r.producto)}</strong></td>
        <td>—</td><td>—</td><td>—</td>
        <td>${priorityBadge(r.prioridad)}</td>
        <td>${Math.round(r.nivel_confianza * 100)}%</td>
        <td>${escapeHtml(r.motivo)}</td>
      </tr>`).join("");
    showAlert(`Análisis completado: ${result.analizadas} productos.`);
    await loadDashboard();
  } catch (e) {
    showAlert(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "Ejecutar análisis";
  }
}

function openProductModal() {
  $("productForm").reset();
  $("productId").value = "";
  $("modalTitle").textContent = "Nuevo producto";
  $("productModal").showModal();
}

function closeProductModal() { $("productModal").close(); }

function editProduct(p) {
  $("productId").value = p.id;
  $("productName").value = p.nombre;
  $("productCategory").value = p.categoria_id;
  $("productPrice").value = p.precio;
  $("productStock").value = p.stock_actual;
  $("productMin").value = p.stock_minimo;
  $("modalTitle").textContent = "Editar producto";
  $("productModal").showModal();
}

async function submitProduct(event) {
  event.preventDefault();
  const id = $("productId").value;
  const payload = {
    nombre: $("productName").value.trim(),
    categoria_id: $("productCategory").value,
    precio: Number($("productPrice").value),
    stock_actual: Number($("productStock").value),
    stock_minimo: Number($("productMin").value),
    activo: true,
  };
  try {
    await api(id ? `/api/productos/${id}` : "/api/productos", {
      method: id ? "PATCH" : "POST",
      body: JSON.stringify(payload),
    });
    closeProductModal();
    showAlert(id ? "Producto actualizado." : "Producto creado.");
    await loadProducts();
    await loadInventory();
    await loadDashboard();
  } catch (e) { showAlert(e.message, true); }
}

async function deactivateProduct(id) {
  if (!confirm("¿Desactivar este producto?")) return;
  try {
    await api(`/api/productos/${id}`, { method: "DELETE" });
    showAlert("Producto desactivado.");
    await loadProducts();
    await loadDashboard();
  } catch (e) { showAlert(e.message, true); }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

async function loadAll() {
  await loadHealth();
  await loadCategories();
  await loadProducts();
  await loadInventory();
  await loadSales();
  await loadDashboard();
  await loadRecommendations();
}

loadAll();
