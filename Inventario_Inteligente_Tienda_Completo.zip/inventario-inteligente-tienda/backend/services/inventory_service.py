from datetime import date, timedelta
from uuid import UUID

from ..supabase_client import get_supabase


def _data(response):
    return response.data or []


def list_categories():
    return _data(
        get_supabase()
        .table("categorias")
        .select("id,nombre")
        .order("nombre")
        .execute()
    )


def create_category(payload):
    return _data(
        get_supabase()
        .table("categorias")
        .insert(payload.model_dump())
        .select("id,nombre")
        .execute()
    )[0]


def list_products(search: str | None = None, categoria_id: UUID | None = None, include_inactive=False):
    query = (
        get_supabase()
        .table("productos")
        .select("id,nombre,categoria_id,precio,stock_actual,stock_minimo,activo,fecha_creacion,categorias(id,nombre)")
        .order("nombre")
    )

    if not include_inactive:
        query = query.eq("activo", True)
    if search:
        query = query.ilike("nombre", f"%{search}%")
    if categoria_id:
        query = query.eq("categoria_id", str(categoria_id))

    rows = _data(query.execute())
    for row in rows:
        category = row.pop("categorias", None)
        row["categoria"] = category["nombre"] if category else "Sin categoría"
    return rows


def get_product(product_id: UUID):
    rows = _data(
        get_supabase()
        .table("productos")
        .select("id,nombre,categoria_id,precio,stock_actual,stock_minimo,activo,fecha_creacion,categorias(id,nombre)")
        .eq("id", str(product_id))
        .limit(1)
        .execute()
    )
    if not rows:
        return None
    row = rows[0]
    category = row.pop("categorias", None)
    row["categoria"] = category["nombre"] if category else "Sin categoría"
    return row


def create_product(payload):
    return get_product(
        UUID(
            _data(
                get_supabase()
                .table("productos")
                .insert(payload.model_dump(mode="json"))
                .select("id")
                .execute()
            )[0]["id"]
        )
    )


def update_product(product_id: UUID, payload):
    changes = payload.model_dump(exclude_unset=True, mode="json")
    if not changes:
        return get_product(product_id)
    _data(
        get_supabase()
        .table("productos")
        .update(changes)
        .eq("id", str(product_id))
        .execute()
    )
    return get_product(product_id)


def deactivate_product(product_id: UUID):
    return update_product(product_id, type("Payload", (), {"model_dump": lambda self, **_: {"activo": False}})())


def register_sale(payload):
    result = get_supabase().rpc(
        "registrar_venta",
        {
            "p_producto_id": str(payload.producto_id),
            "p_cantidad": payload.cantidad,
            "p_fecha_venta": (payload.fecha_venta or date.today()).isoformat(),
        },
    ).execute()
    data = _data(result)
    return data[0] if data else {"ok": True}


def recent_sales(limit=20):
    return _data(
        get_supabase()
        .table("ventas")
        .select("id,producto_id,cantidad,precio_unitario,fecha_venta,productos(nombre)")
        .order("fecha_venta", desc=True)
        .limit(limit)
        .execute()
    )


def inventory_metrics():
    products = list_products()
    today = date.today()
    d7 = (today - timedelta(days=7)).isoformat()
    d30 = (today - timedelta(days=30)).isoformat()

    sales = _data(
        get_supabase()
        .table("ventas")
        .select("producto_id,cantidad,fecha_venta")
        .gte("fecha_venta", d30)
        .lte("fecha_venta", today.isoformat())
        .execute()
    )

    by_product = {}
    for sale in sales:
        pid = sale["producto_id"]
        by_product.setdefault(pid, [])
        by_product[pid].append(sale)

    metrics = []
    for product in products:
        pid = product["id"]
        product_sales = by_product.get(pid, [])
        sold_7 = sum(s["cantidad"] for s in product_sales if s["fecha_venta"] >= d7)
        sold_30 = sum(s["cantidad"] for s in product_sales)
        velocity_7 = round(sold_7 / 7, 3)
        velocity_30 = round(sold_30 / 30, 3)
        trend = round(
            (velocity_7 - velocity_30) / velocity_30, 3
        ) if velocity_30 > 0 else (1.0 if velocity_7 > 0 else 0.0)

        coverage = (
            round(product["stock_actual"] / velocity_7, 1)
            if velocity_7 > 0
            else None
        )

        metrics.append(
            {
                "producto_id": pid,
                "producto": product["nombre"],
                "categoria": product["categoria"],
                "precio": float(product["precio"]),
                "stock_actual": product["stock_actual"],
                "stock_minimo": product["stock_minimo"],
                "ventas_7_dias": sold_7,
                "ventas_30_dias": sold_30,
                "velocidad_diaria_7d": velocity_7,
                "velocidad_diaria_30d": velocity_30,
                "tendencia_7_vs_30": trend,
                "dias_cobertura": coverage,
            }
        )
    return metrics


def dashboard_summary():
    products = list_products()
    metrics = inventory_metrics()
    sales = recent_sales(10)

    low_stock = [
        p for p in products if p["stock_actual"] <= p["stock_minimo"]
    ]

    recommendations = _data(
        get_supabase()
        .table("recomendaciones_ia")
        .select("id,producto_id,prioridad,motivo,nivel_confianza,fecha_analisis,productos(nombre,stock_actual)")
        .order("fecha_analisis", desc=True)
        .limit(50)
        .execute()
    )

    latest_by_product = {}
    for rec in recommendations:
        latest_by_product.setdefault(rec["producto_id"], rec)

    high = [r for r in latest_by_product.values() if r["prioridad"] == "ALTA"]

    return {
        "total_productos": len(products),
        "productos_stock_bajo": len(low_stock),
        "ventas_recientes": sales,
        "productos_prioridad_alta": len(high),
        "resumen_inventario": metrics,
        "recomendaciones": list(latest_by_product.values()),
    }


def save_recommendations(recommendations):
    rows = [r.model_dump(mode="json") for r in recommendations]
    if not rows:
        return []
    return _data(
        get_supabase()
        .table("recomendaciones_ia")
        .insert(rows)
        .select("id,producto_id,prioridad,motivo,nivel_confianza,fecha_analisis")
        .execute()
    )
