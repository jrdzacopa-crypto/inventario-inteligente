import json
import re

import httpx

from ..config import settings
from ..schemas import AIRecommendation


SYSTEM_PROMPT = '''
Eres un analista de inventario para una pequeña tienda.
Tu única tarea es analizar datos de productos y ventas y determinar prioridad de reposición.

Considera conjuntamente:
- stock_actual y stock_minimo;
- ventas_7_dias y ventas_30_dias;
- velocidad_diaria_7d y velocidad_diaria_30d;
- tendencia_7_vs_30;
- dias_cobertura;
- categoria y precio.

No uses una sola regla aislada. Busca señales combinadas de demanda, agotamiento y aceleración o desaceleración.
ALTA significa que existe una necesidad clara y próxima de reposición.
MEDIA significa que conviene vigilar o planificar reposición.
BAJA significa que no hay una señal relevante de reposición inmediata.

Devuelve exclusivamente un JSON válido con una propiedad "recomendaciones".
Cada elemento debe contener:
producto_id, producto, prioridad, motivo, nivel_confianza.

"nivel_confianza" debe ser un número entre 0 y 1.
El motivo debe ser breve, concreto y estar basado en los datos recibidos.
No inventes ventas ni datos.
'''


def _extract_json(text: str):
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not match:
            raise ValueError("Ollama no devolvió un objeto JSON.")
        return json.loads(match.group(0))


async def analyze_inventory(metrics: list[dict]) -> list[AIRecommendation]:
    if not metrics:
        return []

    payload = json.dumps(metrics, ensure_ascii=False, indent=2)

    request = {
        "model": settings.ollama_model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": (
                    "Analiza los siguientes productos. Responde únicamente con JSON.\n\n"
                    + payload
                ),
            },
        ],
        "stream": False,
        "format": {
            "type": "object",
            "properties": {
                "recomendaciones": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "producto_id": {"type": "string"},
                            "producto": {"type": "string"},
                            "prioridad": {
                                "type": "string",
                                "enum": ["ALTA", "MEDIA", "BAJA"],
                            },
                            "motivo": {"type": "string"},
                            "nivel_confianza": {
                                "type": "number",
                                "minimum": 0,
                                "maximum": 1,
                            },
                        },
                        "required": [
                            "producto_id",
                            "producto",
                            "prioridad",
                            "motivo",
                            "nivel_confianza",
                        ],
                    },
                }
            },
            "required": ["recomendaciones"],
        },
        "options": {"temperature": 0.1},
    }

    try:
        async with httpx.AsyncClient(timeout=180) as client:
            response = await client.post(
                f"{settings.ollama_url.rstrip('/')}/api/chat",
                json=request,
            )
            response.raise_for_status()
    except httpx.HTTPError as exc:
        raise ConnectionError(
            "No fue posible comunicarse con Ollama. Comprueba que Ollama esté ejecutándose."
        ) from exc

    try:
        raw = response.json()
        content = raw["message"]["content"]
        parsed = _extract_json(content)
        recommendations = parsed["recomendaciones"]
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError(
            "La respuesta del modelo no tiene el formato esperado."
        ) from exc

    validated = []
    expected = {str(m["producto_id"]): m["producto"] for m in metrics}

    for item in recommendations:
        recommendation = AIRecommendation.model_validate(item)
        if str(recommendation.producto_id) not in expected:
            raise ValueError(
                f"La IA devolvió un producto que no pertenece al análisis: {recommendation.producto_id}"
            )
        validated.append(recommendation)

    if len(validated) != len(metrics):
        raise ValueError(
            "La IA no devolvió una recomendación para todos los productos analizados."
        )

    return validated
