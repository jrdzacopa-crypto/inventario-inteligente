from datetime import date, datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


Priority = Literal["ALTA", "MEDIA", "BAJA"]


class CategoryCreate(BaseModel):
    nombre: str = Field(min_length=2, max_length=80)


class ProductCreate(BaseModel):
    nombre: str = Field(min_length=2, max_length=120)
    categoria_id: UUID
    precio: float = Field(gt=0)
    stock_actual: int = Field(ge=0)
    stock_minimo: int = Field(ge=0)
    activo: bool = True


class ProductUpdate(BaseModel):
    nombre: str | None = Field(default=None, min_length=2, max_length=120)
    categoria_id: UUID | None = None
    precio: float | None = Field(default=None, gt=0)
    stock_actual: int | None = Field(default=None, ge=0)
    stock_minimo: int | None = Field(default=None, ge=0)
    activo: bool | None = None


class SaleCreate(BaseModel):
    producto_id: UUID
    cantidad: int = Field(gt=0)
    fecha_venta: date | None = None


class AIRecommendation(BaseModel):
    producto_id: UUID
    producto: str
    prioridad: Priority
    motivo: str = Field(min_length=10, max_length=500)
    nivel_confianza: float = Field(ge=0, le=1)

    @field_validator("prioridad", mode="before")
    @classmethod
    def normalize_priority(cls, value):
        return str(value).strip().upper()


class AIAnalysisResponse(BaseModel):
    analizadas: int
    recomendaciones: list[AIRecommendation]
    fecha_analisis: datetime


class HealthResponse(BaseModel):
    api: str
    supabase: str
    ollama: str
    modelo: str
