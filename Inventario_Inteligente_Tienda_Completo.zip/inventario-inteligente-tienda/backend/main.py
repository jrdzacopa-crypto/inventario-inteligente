from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .config import settings
from .schemas import (
    AIAnalysisResponse,
    CategoryCreate,
    ProductCreate,
    ProductUpdate,
    SaleCreate,
)
from .services.ai_service import analyze_inventory
from .services.inventory_service import (
    create_category,
    create_product,
    dashboard_summary,
    deactivate_product,
    get_product,
    inventory_metrics,
    list_categories,
    list_products,
    recent_sales,
    register_sale,
    save_recommendations,
    update_product,
)
from .supabase_client import get_supabase


app = FastAPI(
    title="Inventario Inteligente",
    version="1.0.0",
    description="API para productos, inventario, ventas y análisis IA local.",
)

BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/api/health")
async def health():
    supabase_status = "OK"
    ollama_status = "OK"

    try:
        get_supabase().table("categorias").select("id").limit(1).execute()
    except Exception:
        supabase_status = "ERROR"

    try:
        async with httpx.AsyncClient(timeout=3) as client:
            response = await client.get(f"{settings.ollama_url.rstrip('/')}/api/tags")
            response.raise_for_status()
    except Exception:
        ollama_status = "ERROR"

    return {
        "api": "OK",
        "supabase": supabase_status,
        "ollama": ollama_status,
        "modelo": settings.ollama_model,
    }


@app.get("/api/categorias")
def categorias():
    try:
        return list_categories()
    except Exception as exc:
        raise HTTPException(503, "No fue posible consultar las categorías.") from exc


@app.post("/api/categorias", status_code=201)
def nueva_categoria(payload: CategoryCreate):
    try:
        return create_category(payload)
    except Exception as exc:
        raise HTTPException(400, "No fue posible crear la categoría.") from exc


@app.get("/api/productos")
def productos(
    search: str | None = Query(default=None),
    categoria_id: UUID | None = Query(default=None),
    incluir_inactivos: bool = False,
):
    try:
        return list_products(search, categoria_id, incluir_inactivos)
    except Exception as exc:
        raise HTTPException(503, "No fue posible consultar los productos.") from exc


@app.post("/api/productos", status_code=201)
def nuevo_producto(payload: ProductCreate):
    try:
        return create_product(payload)
    except Exception as exc:
        raise HTTPException(400, "No fue posible crear el producto.") from exc


@app.get("/api/productos/{product_id}")
def producto(product_id: UUID):
    try:
        row = get_product(product_id)
    except Exception as exc:
        raise HTTPException(503, "No fue posible consultar el producto.") from exc
    if not row:
        raise HTTPException(404, "Producto no encontrado.")
    return row


@app.patch("/api/productos/{product_id}")
def editar_producto(product_id: UUID, payload: ProductUpdate):
    try:
        if not get_product(product_id):
            raise HTTPException(404, "Producto no encontrado.")
        return update_product(product_id, payload)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, "No fue posible actualizar el producto.") from exc


@app.delete("/api/productos/{product_id}")
def desactivar_producto(product_id: UUID):
    try:
        if not get_product(product_id):
            raise HTTPException(404, "Producto no encontrado.")
        return deactivate_product(product_id)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(400, "No fue posible desactivar el producto.") from exc


@app.get("/api/inventario")
def inventario():
    try:
        return inventory_metrics()
    except Exception as exc:
        raise HTTPException(503, "No fue posible consultar el inventario.") from exc


@app.get("/api/ventas")
def ventas(limit: int = Query(default=50, ge=1, le=200)):
    try:
        return recent_sales(limit)
    except Exception as exc:
        raise HTTPException(503, "No fue posible consultar las ventas.") from exc


@app.post("/api/ventas", status_code=201)
def nueva_venta(payload: SaleCreate):
    try:
        if not get_product(payload.producto_id):
            raise HTTPException(404, "Producto no encontrado.")
        return register_sale(payload)
    except HTTPException:
        raise
    except Exception as exc:
        message = str(exc)
        if "STOCK_INSUFICIENTE" in message:
            raise HTTPException(
                409, "La cantidad de venta es mayor al stock disponible."
            ) from exc
        raise HTTPException(400, "No fue posible registrar la venta.") from exc


@app.get("/api/dashboard")
def dashboard():
    try:
        return dashboard_summary()
    except Exception as exc:
        raise HTTPException(503, "No fue posible cargar el dashboard.") from exc


@app.post("/api/analisis-ia", response_model=AIAnalysisResponse)
async def analisis_ia():
    try:
        metrics = inventory_metrics()
        recommendations = await analyze_inventory(metrics)

        timestamp = datetime.now(timezone.utc)
        for recommendation in recommendations:
            recommendation_dict = recommendation.model_dump(mode="json")
            recommendation_dict["fecha_analisis"] = timestamp.isoformat()

        saved = save_recommendations(recommendations)
        return {
            "analizadas": len(recommendations),
            "recomendaciones": recommendations,
            "fecha_analisis": timestamp,
        }
    except ConnectionError as exc:
        raise HTTPException(503, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(502, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            503, "No fue posible completar el análisis de IA."
        ) from exc


@app.get("/api/recomendaciones")
def recomendaciones():
    try:
        return get_supabase().table("recomendaciones_ia").select(
            "id,producto_id,prioridad,motivo,nivel_confianza,fecha_analisis,productos(nombre,stock_actual)"
        ).order("fecha_analisis", desc=True).limit(100).execute().data or []
    except Exception as exc:
        raise HTTPException(503, "No fue posible consultar las recomendaciones.") from exc
