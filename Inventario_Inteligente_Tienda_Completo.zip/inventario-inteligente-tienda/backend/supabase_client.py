from functools import lru_cache

from supabase import Client, create_client

from .config import settings


@lru_cache(maxsize=1)
def get_supabase() -> Client:
    if not settings.supabase_url or not settings.supabase_anon_key:
        raise RuntimeError(
            "Faltan SUPABASE_URL y SUPABASE_ANON_KEY en el archivo .env."
        )
    return create_client(settings.supabase_url, settings.supabase_anon_key)
