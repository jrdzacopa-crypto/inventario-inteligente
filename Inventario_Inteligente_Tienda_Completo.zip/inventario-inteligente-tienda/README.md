# Inventario Inteligente para una Pequeña Tienda

Prototipo universitario de 9 semanas para administrar productos, inventario y ventas y generar recomendaciones de reposición mediante un modelo de IA local con Ollama.

## Arquitectura

```text
Navegador
   │
   ▼
Frontend HTML/CSS/JS
   │ HTTP
   ▼
FastAPI
   ├──────────────► Supabase (PostgreSQL + Data API)
   │
   └──────────────► Ollama local
                         │
                         ▼
                  análisis de demanda
                         │
                         ▼
                  recomendaciones
                         │
                         ▼
                     Supabase
```

FastAPI sirve también los archivos estáticos del frontend, por lo que el prototipo se puede ejecutar con un solo servidor.

## Requisitos

- Python 3.10 o superior.
- Cuenta gratuita de Supabase.
- Ollama instalado localmente.
- Un modelo local, recomendado para este prototipo: `llama3.2:3b`.
- Navegador moderno.

## 1. Crear Supabase

1. Crear un proyecto en Supabase.
2. En el panel del proyecto abrir **Connect**.
3. Copiar la URL del proyecto y la clave publicable/anon.
4. Crear un archivo `.env` a partir de `.env.example`.
5. Colocar los valores en:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`

El backend usa esta clave únicamente en el servidor. No se coloca en `frontend/app.js`.

## 2. Crear la base de datos

En Supabase abrir **SQL Editor** y ejecutar en este orden:

```text
sql/001_schema.sql
sql/002_seed.sql
```

El primer script crea tablas, relaciones, índices, RLS, políticas y la función transaccional para registrar ventas. El segundo inserta categorías, productos y ventas simuladas.

## 3. Preparar Python

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 4. Instalar Ollama

Instalar Ollama desde su sitio oficial.

Después:

```bash
ollama pull llama3.2:3b
```

Comprobar:

```bash
ollama list
```

En la configuración del proyecto:

```env
OLLAMA_URL=http://127.0.0.1:11434
OLLAMA_MODEL=llama3.2:3b
```

Ollama expone por defecto su API local en `http://127.0.0.1:11434`.

## 5. Ejecutar

Desde la raíz del proyecto:

```bash
uvicorn backend.main:app --reload
```

Abrir:

```text
http://127.0.0.1:8000
```

Documentación de API:

```text
http://127.0.0.1:8000/docs
```

## 6. Comprobar la conexión

Primero:

```text
GET /api/health
```

Debe indicar que la aplicación está funcionando y mostrar el estado de Supabase y Ollama.

También puede probarse desde:

```text
http://127.0.0.1:8000/docs
```

## Flujo de demostración

1. Abrir Dashboard.
2. Revisar los productos de prueba.
3. Ir a Ventas.
4. Registrar una venta.
5. Confirmar que el stock disminuyó.
6. Ir a Análisis IA.
7. Ejecutar el análisis.
8. El backend calcula variables de demanda:
   - stock actual;
   - stock mínimo;
   - ventas 7 días;
   - ventas 30 días;
   - velocidad de venta;
   - tendencia;
   - categoría.
9. Esas variables se envían al modelo local.
10. El modelo devuelve JSON estructurado.
11. FastAPI valida el JSON con Pydantic.
12. Las recomendaciones válidas se guardan en `recomendaciones_ia`.
13. El dashboard muestra la prioridad y el motivo.

## Diseño de la IA

No se utiliza únicamente una regla como `stock < 5`.

Para cada producto, el backend construye un contexto con:

- `stock_actual`
- `stock_minimo`
- `dias_cobertura`
- `ventas_7_dias`
- `ventas_30_dias`
- `velocidad_diaria_7d`
- `velocidad_diaria_30d`
- `tendencia_7_vs_30`
- `categoria`
- `precio`

El LLM local interpreta conjuntamente esos factores y devuelve:

```json
{
  "producto_id": "UUID",
  "producto": "Playera negra",
  "prioridad": "ALTA",
  "motivo": "El inventario es bajo frente al ritmo reciente de ventas.",
  "nivel_confianza": 0.89
}
```

La confianza es una estimación del modelo y no una probabilidad estadística calibrada. Para un proyecto universitario se muestra como indicador de confianza de la recomendación, no como precisión científica.

## Manejo de errores

- Supabase no disponible: el endpoint responde con HTTP 503 y el frontend muestra un mensaje entendible.
- Ollama no disponible: el análisis responde con HTTP 503; no se inventa una recomendación de IA.
- JSON inválido: se intenta extraer el objeto JSON y se valida nuevamente; si no es válido, se informa el error.
- Producto inexistente: HTTP 404.
- Venta mayor al stock: la función SQL rechaza la operación.
- Datos incompletos: Pydantic valida las entradas.
- Errores inesperados: FastAPI registra el detalle en servidor y devuelve un mensaje general.

## Estructura

```text
inventario-inteligente-tienda/
├── backend/
│   ├── main.py
│   ├── config.py
│   ├── schemas.py
│   ├── supabase_client.py
│   └── services/
│       ├── ai_service.py
│       └── inventory_service.py
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── sql/
│   ├── 001_schema.sql
│   └── 002_seed.sql
├── tests/
│   └── test_ai_service.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 9 semanas sugeridas

| Semana | Trabajo |
|---|---|
| 1 | Requisitos, arquitectura y diseño de BD |
| 2 | Supabase, tablas, relaciones y datos de prueba |
| 3 | Backend FastAPI y CRUD de productos |
| 4 | Inventario y registro transaccional de ventas |
| 5 | Frontend: dashboard, productos e inventario |
| 6 | Frontend: ventas y análisis |
| 7 | Integración Ollama y salida JSON |
| 8 | Pruebas, validaciones y manejo de errores |
| 9 | Documentación, presentación y demostración |

## Nota de seguridad

Este prototipo está pensado para demostración académica local. No incluye autenticación de usuarios ni autorización por roles. Antes de llevarlo a producción se debe agregar autenticación, políticas RLS basadas en usuarios y una clave de servidor protegida según el modelo de despliegue.

No subir `.env` a Git.
