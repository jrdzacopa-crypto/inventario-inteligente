-- Datos simulados para demostración.
-- Si se ejecuta varias veces, las categorías existentes no se duplican.
insert into public.categorias(nombre)
values
  ('Ropa'),
  ('Bebidas'),
  ('Abarrotes'),
  ('Limpieza'),
  ('Papelería')
on conflict (nombre) do nothing;

insert into public.productos(nombre, categoria_id, precio, stock_actual, stock_minimo)
select x.nombre, c.id, x.precio, x.stock_actual, x.stock_minimo
from (
  values
    ('Playera negra', 'Ropa', 299.00, 3, 8),
    ('Playera blanca', 'Ropa', 279.00, 18, 8),
    ('Pantalón mezclilla', 'Ropa', 549.00, 10, 5),
    ('Refresco cola 600ml', 'Bebidas', 22.00, 30, 12),
    ('Agua natural 1L', 'Bebidas', 18.00, 45, 15),
    ('Café molido 250g', 'Abarrotes', 115.00, 6, 6),
    ('Arroz 1kg', 'Abarrotes', 34.00, 24, 8),
    ('Detergente 1L', 'Limpieza', 68.00, 5, 7),
    ('Jabón de baño', 'Limpieza', 29.00, 20, 8),
    ('Cuaderno profesional', 'Papelería', 42.00, 40, 10)
) as x(nombre, categoria, precio, stock_actual, stock_minimo)
join public.categorias c on c.nombre = x.categoria
where not exists (
  select 1 from public.productos p where p.nombre = x.nombre
);

-- Ventas históricas simuladas.
-- Se insertan solamente si no existen ventas para estos productos.
do $$
declare
  r record;
begin
  if not exists (select 1 from public.ventas limit 1) then
    for r in
      select p.id, p.precio, p.nombre
      from public.productos p
    loop
      if r.nombre = 'Playera negra' then
        insert into public.ventas(producto_id, cantidad, precio_unitario, fecha_venta)
        values
          (r.id, 6, r.precio, current_date),
          (r.id, 5, r.precio, current_date - 1),
          (r.id, 4, r.precio, current_date - 3),
          (r.id, 5, r.precio, current_date - 6),
          (r.id, 15, r.precio, current_date - 15),
          (r.id, 30, r.precio, current_date - 25);
      elsif r.nombre = 'Detergente 1L' then
        insert into public.ventas(producto_id, cantidad, precio_unitario, fecha_venta)
        values
          (r.id, 1, r.precio, current_date - 2),
          (r.id, 1, r.precio, current_date - 5),
          (r.id, 4, r.precio, current_date - 14),
          (r.id, 5, r.precio, current_date - 25);
      elsif r.nombre = 'Refresco cola 600ml' then
        insert into public.ventas(producto_id, cantidad, precio_unitario, fecha_venta)
        values
          (r.id, 2, r.precio, current_date - 1),
          (r.id, 3, r.precio, current_date - 4),
          (r.id, 8, r.precio, current_date - 12),
          (r.id, 10, r.precio, current_date - 23);
      elsif r.nombre = 'Cuaderno profesional' then
        insert into public.ventas(producto_id, cantidad, precio_unitario, fecha_venta)
        values
          (r.id, 1, r.precio, current_date - 9),
          (r.id, 2, r.precio, current_date - 18),
          (r.id, 2, r.precio, current_date - 27);
      elsif r.nombre = 'Agua natural 1L' then
        insert into public.ventas(producto_id, cantidad, precio_unitario, fecha_venta)
        values
          (r.id, 3, r.precio, current_date - 1),
          (r.id, 4, r.precio, current_date - 5),
          (r.id, 8, r.precio, current_date - 16),
          (r.id, 10, r.precio, current_date - 28);
      end if;
    end loop;
  end if;
end $$;
