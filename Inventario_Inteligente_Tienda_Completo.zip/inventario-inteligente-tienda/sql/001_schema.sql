-- Inventario Inteligente para una Pequeña Tienda
-- Ejecutar completo en Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.categorias (
  id uuid primary key default gen_random_uuid(),
  nombre varchar(80) not null unique
);

create table if not exists public.productos (
  id uuid primary key default gen_random_uuid(),
  nombre varchar(120) not null,
  categoria_id uuid not null references public.categorias(id) on update cascade on delete restrict,
  precio numeric(12,2) not null check (precio > 0),
  stock_actual integer not null default 0 check (stock_actual >= 0),
  stock_minimo integer not null default 0 check (stock_minimo >= 0),
  activo boolean not null default true,
  fecha_creacion timestamptz not null default now()
);

create table if not exists public.ventas (
  id uuid primary key default gen_random_uuid(),
  producto_id uuid not null references public.productos(id) on update cascade on delete restrict,
  cantidad integer not null check (cantidad > 0),
  precio_unitario numeric(12,2) not null check (precio_unitario > 0),
  fecha_venta date not null default current_date,
  fecha_registro timestamptz not null default now()
);

create table if not exists public.recomendaciones_ia (
  id uuid primary key default gen_random_uuid(),
  producto_id uuid not null references public.productos(id) on update cascade on delete cascade,
  prioridad varchar(10) not null check (prioridad in ('ALTA','MEDIA','BAJA')),
  motivo varchar(500) not null,
  nivel_confianza numeric(5,4) not null check (nivel_confianza >= 0 and nivel_confianza <= 1),
  fecha_analisis timestamptz not null default now()
);

create index if not exists idx_productos_categoria on public.productos(categoria_id);
create index if not exists idx_productos_activo on public.productos(activo);
create index if not exists idx_ventas_producto_fecha on public.ventas(producto_id, fecha_venta desc);
create index if not exists idx_ventas_fecha on public.ventas(fecha_venta desc);
create index if not exists idx_recomendaciones_producto_fecha on public.recomendaciones_ia(producto_id, fecha_analisis desc);
create index if not exists idx_recomendaciones_prioridad on public.recomendaciones_ia(prioridad);

-- Función transaccional: inserta venta y descuenta stock.
create or replace function public.registrar_venta(
  p_producto_id uuid,
  p_cantidad integer,
  p_fecha_venta date default current_date
)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  v_producto public.productos%rowtype;
  v_venta public.ventas%rowtype;
begin
  if p_cantidad is null or p_cantidad <= 0 then
    raise exception 'CANTIDAD_INVALIDA';
  end if;

  select *
  into v_producto
  from public.productos
  where id = p_producto_id
  for update;

  if not found then
    raise exception 'PRODUCTO_NO_EXISTE';
  end if;

  if not v_producto.activo then
    raise exception 'PRODUCTO_INACTIVO';
  end if;

  if p_cantidad > v_producto.stock_actual then
    raise exception 'STOCK_INSUFICIENTE';
  end if;

  update public.productos
  set stock_actual = stock_actual - p_cantidad
  where id = p_producto_id;

  insert into public.ventas(producto_id, cantidad, precio_unitario, fecha_venta)
  values (p_producto_id, p_cantidad, v_producto.precio, coalesce(p_fecha_venta, current_date))
  returning * into v_venta;

  return jsonb_build_object(
    'ok', true,
    'venta_id', v_venta.id,
    'producto_id', p_producto_id,
    'cantidad', p_cantidad,
    'stock_restante', v_producto.stock_actual - p_cantidad
  );
end;
$$;

-- RLS para el prototipo.
-- La aplicación no tiene autenticación; por eso estas políticas permiten
-- las operaciones necesarias al rol anon. Antes de producción deben sustituirse
-- por políticas ligadas a usuarios autenticados.

alter table public.categorias enable row level security;
alter table public.productos enable row level security;
alter table public.ventas enable row level security;
alter table public.recomendaciones_ia enable row level security;

drop policy if exists categorias_select_anon on public.categorias;
drop policy if exists categorias_insert_anon on public.categorias;
create policy categorias_select_anon on public.categorias for select to anon using (true);
create policy categorias_insert_anon on public.categorias for insert to anon with check (true);

drop policy if exists productos_select_anon on public.productos;
drop policy if exists productos_insert_anon on public.productos;
drop policy if exists productos_update_anon on public.productos;
create policy productos_select_anon on public.productos for select to anon using (true);
create policy productos_insert_anon on public.productos for insert to anon with check (true);
create policy productos_update_anon on public.productos for update to anon using (true) with check (true);

drop policy if exists ventas_select_anon on public.ventas;
drop policy if exists ventas_insert_anon on public.ventas;
create policy ventas_select_anon on public.ventas for select to anon using (true);
create policy ventas_insert_anon on public.ventas for insert to anon with check (true);

drop policy if exists recomendaciones_select_anon on public.recomendaciones_ia;
drop policy if exists recomendaciones_insert_anon on public.recomendaciones_ia;
create policy recomendaciones_select_anon on public.recomendaciones_ia for select to anon using (true);
create policy recomendaciones_insert_anon on public.recomendaciones_ia for insert to anon with check (true);

grant usage on schema public to anon;
grant select, insert on public.categorias to anon;
grant select, insert, update on public.productos to anon;
grant select, insert on public.ventas to anon;
grant select, insert on public.recomendaciones_ia to anon;
grant execute on function public.registrar_venta(uuid, integer, date) to anon;
